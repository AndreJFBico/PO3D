// Copyright 2013 Pedro B. Pascoal
package po3d;

import thor.demo.*;

public class Viewer {
	public static void main(String args[]) {
		new ModelViewer(512, 512, null);
	}
}

