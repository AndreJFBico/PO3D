package thor.model.geoset;

public enum VoxelNeighborType {
	UNASSIGNED,
	F_NEIGHBOR,
	E_NEIGHBOR,
	V_NEIGHBOR
}
