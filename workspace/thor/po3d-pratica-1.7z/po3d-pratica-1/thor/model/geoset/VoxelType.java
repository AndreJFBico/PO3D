package thor.model.geoset;

public enum VoxelType {
	BOUNDARY_VOXEL, 
	PROBABLE_INSIDE_VOXEL, 
	INSIDE_VOXEL, 
	OUTSIDE_VOXEL
}
